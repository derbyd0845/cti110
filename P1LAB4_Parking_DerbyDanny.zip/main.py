''' Type your code here. '''

# P1LAB4_Parking_DerbyDanny
# CTI 110
# 6/16/2021

#Create No Parking 2:00 - 6:00 a.m.

print('  NO PARKING')
print('2:00 - 6:00 a.m.')
